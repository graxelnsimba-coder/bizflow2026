BizFlow Gestion - PWA files

Included: manifest.json, service-worker.js, icons/icon-192.png and icons/icon-512.png, plus integration snippet.

IMPORTANT: Upload manifest.json, service-worker.js, and the icons folder to the repository ROOT (same level as index.html). Copy the HEAD lines from pwa-integration-snippet.html into index.html inside <head>, and copy the service-worker script registration before </body>. Commit, wait for GitHub Pages deployment, then open the site in Chrome and use menu > Install app / Add to Home screen.

The service worker is a basic cache implementation, not a guarantee that all BizFlow features/data work offline.
