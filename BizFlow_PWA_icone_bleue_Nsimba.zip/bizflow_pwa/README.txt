BizFlow Gestion — Pack PWA avec icône bleue Nsimba

Contenu :
- manifest.json : nom, couleur, mode d’affichage et icônes
- service-worker.js : cache de base pour démarrage et ressources
- icons/icon-192.png : icône 192x192
- icons/icon-512.png : icône 512x512
- pwa-integration-snippet.html : code à intégrer dans index.html

Installation dans GitHub :
1. Dézippe le pack.
2. Dans le dépôt bizflow2026, ajoute manifest.json et service-worker.js à la racine (au même niveau que index.html).
3. Ajoute le dossier icons à la racine, avec les deux PNG.
4. Ouvre index.html et ajoute le code de pwa-integration-snippet.html aux emplacements indiqués dans ce fichier. Ne remplace pas tout index.html.
5. Enregistre/commit les modifications et attends le déploiement GitHub Pages.
6. Ouvre le site dans Chrome Android et choisis le menu ⋮ puis Installer l’application / Ajouter à l’écran d’accueil.

Note : le service worker est un cache de base ; il ne garantit pas que toutes les fonctions et données fonctionneront hors connexion.
